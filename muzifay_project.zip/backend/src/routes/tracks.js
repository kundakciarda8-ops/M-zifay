const express = require('express');
const router = express.Router();
const Track = require('../models/Track');
const streamProxy = require('../utils/streamProxy');
router.get('/trending', async (req,res)=>{
  const top = await Track.find({}).limit(10).sort({plays:-1});
  const data = top.map(t => ({ _id: t._id, title: t.title, artist: t.artist, streamUrl:`${process.env.PUBLIC_URL || 'http://localhost:4000'}/tracks/stream/${t._id}`}));
  res.json(data);
});
router.get('/stream/:id', async (req,res)=>{
  try {
    const id = req.params.id;
    const track = await Track.findById(id);
    if(!track) return res.status(404).end();
    await streamProxy.streamFile(track.storagePath, req, res);
  } catch(err){ console.error(err); res.status(500).end(); }
});
module.exports = router;
